let str="   Lorem ipsum dolor sit amet, consectet    "
let num="99891"
let str2="Audit"
console.log(str.length) // uzunligini topib beradi;

console.log(str.charAt(3))  //3 indeksda qaysi harf borligini aniqlaydi

console.log(str.charCodeAt(1))  //charCodeAt jadvalni ko'rsatadi // Unicode raqamni topib beradi

console.log(str.concat("Eshmat","Toshmat")) // so'zlarni birlashtiradi
console.log(str.concat("Eshmat ",str2)) // so'zlarni birlashtiradi

console.log(str.endsWith("consectet ")) // shu so'z bilan tugayabdmi true || false chiqadi

console.log(str.startsWith("Lorem"))  // Lorem so'zi bilan boshlanadimi //true chiqadi

console.log(str.includes("o"))  // o harfi bo'lsa true bo'lmasa false

console.log(str.indexOf("i"))  //i harfini boshidan qaysi indexdaligini topib beradi  //6

console.log(str.lastIndexOf("i")) //i harfini ohiridan nechinchi indexda joylashganini topib beradi //19

console.log(num.padEnd(10,"0")) // 10 ta so'z bo'lishi uchun 0 sonini qo'shdi oxiriga

console.log(num.padStart(10,0))  // 10 ta so'z bo'lishi uchu boshidan 0 qoshdi

console.log(str2.repeat(3))    //repeat-qaytarmoq 3-marta qaytaradi

console.log(str.replace(" ",",")) // probildan o'rniga vergul qo'yib ket digani faqat bittasi
console.log(str.replace("L",",")) //L di o'rniga vergul qo'y digani faqat bittasi

console.log(str.replaceAll(" ",",")) //hamma probil qo'yilgan joyga vergul qo'yib chiq degani

console.log(str.slice(7))  // bu holatda 7 indexdan boshlab oxirigacha so'zni kopirovat qilib beradi
console.log(str.slice(7,15)) //bu holatda 8 indexdan boshlab 15 indexgacha kopirovat qiladi

console.log(str.split(" ")) // bu holatda probil tashlangan har bitta so'zni ARRAY ga solib beradi probil qo'yilmasa har bitta harfni Arrayga soladi

let test=str.split(" ");  // bu holatda ARRAYga o'tildi va test.join orqali bajarildi
console.log(test.join(","))

console.log(str.toLowerCase())  // hamasini kichik harfga o'tkazib beradi

console.log(str.toUpperCase())  // hammsini katta harfga otkazib beradi

console.log(str.trim())  // boshidagi va ohiridagi bo'sh joylarni o'chiradi


console.log(str.trimStart()) // faqat boshidagi bo'sh joyni olib tashlaydi

console.log(str.trimEnd()) // faqat ohiridagi bo'sh joyni olib tashlaydi


let sum=(str.split(" "));

console.log(delete sum[0]);
