let age=prompt("Yoshingizni kiriting");


if(age>0 &&  age<18){
   alert("You are a minor");
    
}
else if(age>=18 && age<=60) {

    alert("You are an adult");
}

else if(age>60 ){
alert("Your are a senior citzen" )

}



else{
    alert("Please enter a number")
    
}

