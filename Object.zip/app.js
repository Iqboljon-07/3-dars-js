
// object

// CRUD;
// r-read;
// create-qoshish;
// delete-o'chirish;
// update=izmenit qilish


//1
//read-o'qish
// let user={name:"usernames",age:23}
// let nimakerak=prompt("tanlang")
// // console.log(user.name)
// //yoki
// console.log(user[nimakerak])




//2
//create-qo'shish
// let user={name:"usernames",age:23}

// user.address="Toshkent";
// //yoki

// user["number"]="903438330"

// console.log(user)


//3
//delete-o'chirish
// let user={name:"usernames",age:23};
// user.address="Toshkent";
// delete user.name;
// //yoki
// delete user["age"]
// console.log(user);

//4

//update-izmenit qilish

// let user={name:"usernames",age:23};
// user.name="Iqboljon";
// //yoki
// user["age"]=28
// console.log(user);
