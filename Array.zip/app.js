//read;
// let fruits=["orange","apple","banana"];

// console.log(fruits[1])



// //create

// let fruits=["orange","apple","banana"];
// fruits[3]="graped"
// console.log(fruits);


//delete
// let fruits=["orange","apple","banana"];

// delete fruits[2];
// console.log(fruits);


//update

// let fruits=["orange","apple","banana"];

// fruits[0]="limon"
// console.log(fruits)